from setuptools import setup

package_name = 'turtle_party'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', ['launch/turtles_gone_wild.launch.py']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Rushik Sai',
    maintainer_email='jakka@uni-bremen.de',
    description='Turtle party package with TF2 followers',
    license='MIT',
    entry_points={
        'console_scripts': [
            'follow = turtle_party.follow:main',
            'broadcaster = turtle_party.broadcaster:main',
        ],
    },
)

