from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    return LaunchDescription([
        # Turtlesim window
        Node(
            package='turtlesim',
            executable='turtlesim_node',
            name='sim'
        ),

        # Broadcasters (1 per turtle)
        Node(
            package='turtle_party',
            executable='broadcaster',
            name='broadcaster1',
            parameters=[{'turtle_name': 'turtle1'}]
        ),
        Node(
            package='turtle_party',
            executable='broadcaster',
            name='broadcaster2',
            parameters=[{'turtle_name': 'turtle2'}]
        ),
        Node(
            package='turtle_party',
            executable='broadcaster',
            name='broadcaster3',
            parameters=[{'turtle_name': 'turtle3'}]
        ),

        # Followers (each follows the one before)
        Node(
            package='turtle_party',
            executable='follow',
            name='follow2',
            parameters=[
                {'target_frame': 'turtle1'},
                {'turtle_name': 'turtle2'}
            ]
        ),
        Node(
            package='turtle_party',
            executable='follow',
            name='follow3',
            parameters=[
                {'target_frame': 'turtle2'},
                {'turtle_name': 'turtle3'}
            ]
        ),
    ])

